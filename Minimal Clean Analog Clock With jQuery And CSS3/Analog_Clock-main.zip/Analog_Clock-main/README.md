# Analog_Clock
Beautiful Analog Clock using HTML, CSS, JS with jQuery
