## Analog clock ( Javascript )
Simple implementation of analog clock written for web

<br/>

### Live demo
https://accelerator-one.github.io/analog-clock-javascript/public/index.html

<br/>

### Screenshot
![Analog clock](Screenshot.png)