# analog-clock
Simple implementation of an analog clock developed for web

# Demo
https://accelerator-one.github.io/analog-clock/

# Screenshot
![Analog Clock](./screenshot.png)
