# Uptime

What time is it? up!

An [/r/badUIbattles](https://www.reddit.com/r/badUIbattles/comments/pon2t6/a_convenient_analog_clock/) submission. Now available as a wallpaper using [Lively](https://github.com/rocksdanister/lively)!

[Demo](https://izeau.github.io/uptime/)

Extras:

- [numbered version](https://izeau.github.io/uptime/?numbered)
- [no bounce](https://izeau.github.io/uptime/?bounce=no)
- [numbered, no bounce](https://izeau.github.io/uptime/?numbered&bounce=no)
